export const fruits = [{
    id: 1,
    name: "Lemon",
    category: "citrus"
},
{
    id: 2,
    name: "Pink Lady",
    category: "apples"
},
{
    id: 3,
    name: "Papaya",
    category: "exotic"
},
{
    id: 4,
    name: "Mango",
    category: "exotic"
},
{
    id: 5,
    name: "Blueberry",
    category: "berries"
},
{
    id: 6,
    name: "Strawberry",
    category: "berries"
},

];