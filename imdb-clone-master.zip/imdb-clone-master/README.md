Inlämingsarbete för kurs Javascript Backend av Natanael Augustin
Kursinnehåll : IMDB-klon
Lärare : Alexander Andersson

imdb_clone repo
https://63a0823e80da9700083e11d2--superlative-bubblegum-5d48a4.netlify.app/
