import React from "react";
import "./Footer.css";


function Footer() {
  return (
   
    <div className="footer">
      <div className="footer-container"> <a className="footer-text" href="https://github.com/NatanaelAugustin">Made by @Natanael Augustin</a> </div>
    </div>
    
  );
}

export default Footer;
